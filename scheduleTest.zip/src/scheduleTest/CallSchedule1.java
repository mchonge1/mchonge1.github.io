package scheduleTest;

import java.time.LocalDateTime;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

@DisallowConcurrentExecution
public class CallSchedule1 implements Job{
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException{
		System.out.println("Job Executed [" + LocalDateTime.now() + "]" + "시작1"); 
		try {
			Thread.sleep(1000*3);
		} catch(Exception e){
				e.printStackTrace();
		}
//		for(long i=0; i<2000000000; i++) {
//			
//		}
		System.out.println("Job Executed [" + LocalDateTime.now() + "]" + "끝1"); 
	}
}

