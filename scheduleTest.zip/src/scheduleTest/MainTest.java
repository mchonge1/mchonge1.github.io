package scheduleTest;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import java.util.LinkedList;
import java.util.List;

import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.impl.StdSchedulerFactory;

public class MainTest {

	
	public static void main(String[] args){
		//System.out.println("작업을 시작하시겠습니까");
		//text 파일 읽어와서 설정
		//Scanner sc = new Scanner(System.in);
		
		//System.out.println(sc.next());
		//http://www.quartz-scheduler.org/downloads/
		//https://repo1.maven.org/maven2/org/slf4j/slf4j-nop/1.7.30/
		
		//SchedulerFactory schedulerFactory = new StdSchedulerFactory();
		
		SchedulerFactory schedulerFactory = new StdSchedulerFactory();
		String Exp1 = "0/1 * * * * ?";
		String Exp2 = "0/5 * * * * ?";
    
    try {

        JobDetail job1 = newJob(CallSchedule1.class)
            .withIdentity("jobName1", Scheduler.DEFAULT_GROUP)
            .build();
        Trigger trigger1 = newTrigger()
            .withIdentity("trggerName1", Scheduler.DEFAULT_GROUP)
            .withSchedule(cronSchedule(Exp1))
            .withPriority(10)
            .build();
        
        JobDetail job2 = newJob(CallSchedule2.class)
            .withIdentity("jobName2", Scheduler.DEFAULT_GROUP)
            .build();
        Trigger trigger2 = newTrigger()
            .withIdentity("trggerName2", Scheduler.DEFAULT_GROUP)
            .withSchedule(cronSchedule(Exp2))
            .withPriority(5)
            .build();
        

        List<JobDetail> jobDetailQueue = new LinkedList<>();
        jobDetailQueue.add(job1);
        jobDetailQueue.add(job2);
        job1.getJobDataMap().put("JobDetailQueue", jobDetailQueue);

        // 스케줄러 실행 및 JobDetail과 Trigger 정보로 스케줄링
        Scheduler scheduler = schedulerFactory.getScheduler();
        scheduler.start();
        scheduler.scheduleJob(job1, trigger1);
        scheduler.scheduleJob(job2, trigger2);
        //Thread.sleep(3 * 1000);  // Job이 실행될 수 있는 시간 여유를 준다


//        Scheduler scheduler = schedulerFactory.getScheduler();   
//        scheduler.start();     
//        scheduler.scheduleJob(job, trigger);
//        scheduler.scheduleJob(job2, trigger2);        
        
    } catch(Exception e) {
        e.printStackTrace();
    }      
		

	}

}
